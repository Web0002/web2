

<!doctype html>
<html lang="en">
 <head><meta http-equiv="Content-Type" content="text/html; charset=euc-jp">

  
   <title>Login To Love Calculator Prank</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />  
  <meta name="description" content="Login To See Your Friend's Crush name">
  <meta property="og:title" content="Login To See Your Friend's Crush name" />
  <meta property="og:image" content="/love/lovelogo.png" />
   <meta name="theme-color" content="#fa7ebd"/>
  
  
 

  <link rel="stylesheet" type="text/css" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script type="text/javascript" src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="/stylesheets/main.css?v=680" />

 <link rel="manifest" href="/manifest.json">


<style>
    @import url("https://fonts.googleapis.com/css?family=Sniglet");


.navbar{
border-color:#fa7ebd;
}

.navbar-inverse {
    background-color: #fa7ebd !important;
}
body{
  background-image: url(/love/pink-bg5.jpg);
}

</style>

 </head>
 <body>
 

 <nav class="navbar navbar-default navbar-static-top navbar-inverse">
  <div class="container">
    <ul class="nav navbar-nav">
      <li class="active">
        <a style="background-color: #fa7ebd !important;"  href="/love/">   <img src="lovelogo.png" width="83" height="32" style="margin-left:3px"></a>
      </li>
    </ul>
  </div>
</nav>




<div class="container">
  <center>
  <h2>Login With Link and Password</h2>
 <input type="text" name="name" class="text-input ng-pristine ng-untouched ng-valid ng-scope" placeholder="Paste Your Link" id="nametb" ng-model="name" required><br class="ng-scope">

 <input type="number" name="name" class="text-input ng-pristine ng-untouched ng-valid ng-scope" placeholder="Enter 4 Digit Password" 
oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"
 maxlength="4" id="pwdtb" ng-model="name"><br class="ng-scope" required>



 <h2> OR With Secret Code</h2>

 <input type="text" name="name" class="text-input ng-pristine ng-untouched ng-valid ng-scope" placeholder="Enter Your Secret Code" id="scodetb" ng-model="name" required><br class="ng-scope">

 <p style="color: red;font-size:2rem;" id="error"></p>


    <a class="normal-button ng-binding ng-scope" id="logbtn" onclick="login()" type="sumbit" style="margin-bottom:20px"> Log in  <span class="glyphicon glyphicon-hand-right"></span></a>

  </form>
<br>

  <!-- <a href="https://www.getlinks.info/love/findmylink.php" target="_blank" style="background-color: #ff6390;font-weight: 1; margin: 5px;" class="normal-button pink-rounded">
 Forgot Your Link? Click Me
</a>  -->


<h5>Still Not Able To Login?</h5>
<h4>Contact Us Now</h4>

 <a href="https://www.instagram.com/_u/interstingapps/" target="_blank" style="background-color: #ff6390;font-weight: 1; margin: 5px;" class="normal-button pink-rounded">
  <i class="glyphicon glyphicon-send" id="icon"></i> DM ON INSTAGRAM
</a>


 <a href="https://www.facebook.com/myinterstingapps/" target="_blank" style="background-color: #ff6390;font-weight: 1; margin: 5px;" class="normal-button pink-rounded">
  <i class="glyphicon glyphicon-send" id="icon"></i> Message on FB 
</a>

<!--
<a href="mailto:support@getlinks.info" target="_blank" style="background-color: #ff6390;font-weight: 1; margin: 5px;" class="normal-button pink-rounded">
  <i class="glyphicon glyphicon-send" id="icon"></i> Email Us 
</a>
-->

</center>

</div>

<style>
#footer {
    height: 110px;
   
    bottom: 0px;
    left: 0px;
    right: 0px;
    margin-bottom: 0px;
	font: 18px arial, sans-serif;
}

.declaimer
{
color : #7C7E83;
font: 12px arial, sans-serif;

}

.copyrights
{
color : #7C7E83;
font: 15px arial, sans-serif;
font-weight:bold;

}
.dots
{
font: 18px arial, sans-serif;
color : #566AF7;
}

</style>




<footer>
<hr style="margin-bottom: 5px;">
 <div>
 <center>

 	
<center>

<br>


<center>
 FOLLOW US<br>
<a class="normal-button pink-rounded fab fa-instagram" target="_blank" style="margin-bottom: 5px;height: 24px; line-height: 1.5; "  href="https://www.instagram.com/_u/interstingapps/">
</a>
<a class="normal-button pink-rounded fab fa-facebook" target="_blank" style="margin-bottom: 5px;height: 24px;background-color: #3b5998; line-height: 1.5; "  href="https://www.facebook.com/myinterstingapps/">
</a>
</center>

<a class="normal-button pink-rounded" style="margin-bottom: 5px;height: 24px;background-color: #00d1b2; line-height: 1.5; " href="/contact"><i class="glyphicon glyphicon-paste"></i> Give Feedback</a>
<a class="normal-button pink-rounded" style="margin-bottom: 5px;height: 24px;background-color: #00d1b2; line-height: 1.5;" href="/more" ><i class="glyphicon glyphicon-phone"></i> More apps</a>





<p class="declaimer">Disclaimer: All content is provided for fun and entertainment purposes only</p>
<p class="copyrights">&#169; 2019 getLinks.info</p>
<p style="margin-top:-10px "><a target="_blank" href="/about-us">About Us</a> |<a <a target="_blank" href="/privacy-policy"> Privacy Policy </a> | <a <a target="_blank" href="/tnc"> Terms of Use</a></p>

</center>
 
 
</center>
 </div>
</footer>
</section>

<script type="text/javascript">
      
  function login(){
    
    var name=$("#nametb").val();
      var pwd=$("#pwdtb").val();
      var scode=$("#scodetb").val();
      var userid;

    $("#error").text("");
   
if(scode!=""){
  var arr = scode.split("-");
pwd=arr[0];
userid=arr[1];

if(typeof userid === "undefined" || userid.length!==7){
      $("#error").text("Secret Code is Not Valid");
        return;
     }

     if(typeof pwd === "undefined" || pwd.length!==4){
      $("#error").text("Secret Code is Not Valid");
        return;
     }

}else
{ if(name==""){
        $("#error").text("Enter Your Link");
        return;
    }
    if(pwd==""){
        $("#error").text("Enter Valid Password");
        return;
    }
     if(pwd.length<4){
        $("#error").text("Enter Valid Password");
        return;
    }
    
    if(name.indexOf("/love/c/")==-1){
      $("#error").text("Link is Not Valid");
        return;
    }

     userid=name.substr(name.indexOf("/love/c/")+8, 7) ;
     if(userid.length!==7){
      $("#error").text("Link is Not Valid");
        return;
     }

  }

     $.ajax({
    url: 'verifypin.php?userid='+userid+"&pwd="+pwd,
    type: 'GET',
    contentType: 'application/json; charset=utf-8',
    dataType: 'json', 
    async: true,
    beforeSend: function( xhr ) {
   $("#logbtn").html("Please Wait");
  },
    success: function(data) {
            if(!data.error){
          $("#logbtn").html("Success");              
            window.location="/love/";
            return;
          }else{
        $("#error").text(data.msg);
   $("#logbtn").html(' Log in  <span class="glyphicon glyphicon-hand-right"></span>');


          }
           
            



    }

    ,
  error:function(msg) {
   $("#logbtn").html(' Log in  <span class="glyphicon glyphicon-hand-right"></span>');
        alert("Something went Wrong");


    }
  });




  }

</script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-136327487-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-136327487-1');
</script>


 </body>
</html>
